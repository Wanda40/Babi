const help = (prefix, pushname) => {
	return `*[BOT] Bentol*

Halo *${pushname}*

*Note : Semua Fitur Tidak Menggunakan [ ] atau ( ). Jangan Lupa Donasi cuyy*

*Education*
╔⊱ *${prefix}brainly* [query]
╠⊱ *${prefix}kbbi* [query]
╠⊱ *${prefix}wiki* [query] Wikipedia Indonesia
╚⊱ *${prefix}wikien* [query] Wikipedia English

*Information*
╔⊱ *${prefix}infocuaca* [daerah]
╠⊱ *${prefix}infoig* [@username]
╠⊱ *${prefix}jadwaltvnow*
╠⊱ *${prefix}jadwalshalat*
╚⊱ *${prefix}jadwaltv* [channel]

*Primbon*
╔⊱ *${prefix}artinama* [nama]
╠⊱ *${prefix}artimimpi* [teks]
╠⊱ *${prefix}ramalnohp* [0812xxx]
╠⊱ *${prefix}cekjodoh* [nama] [pasangan]
╚⊱ *${prefix}zodiak* [nama tgl-bln-thn]

*Download*
╔⊱ *${prefix}playmp3* [judul]
╠⊱ *${prefix}playmp4* [judul]
╚⊱ *${prefix}ytmp3* [link]

*Animek*
╔⊱ *${prefix}waifu*
╠⊱ *${prefix}waifuv2*
╠⊱ *${prefix}hentai*
╠⊱ *${prefix}trap*
╠⊱ *${prefix}anime*
╠⊱ *${prefix}animequotes*
╠⊱ *${prefix}animewallpaper*
╚⊱ *${prefix}nekonime*

*Sticker*
╔⊱ *${prefix}sticker*
╠⊱ *${prefix}tsticker*
╚⊱ *${prefix}toimg*

*Creator*
╔⊱ *${prefix}phub* [teks1] [teks2]
╠⊱ *${prefix}glitch* [teks1] [teks2]
╠⊱ *${prefix}nulis* [teks]
╠⊱ *${prefix}tahta* [teks]
╠⊱ *${prefix}qrcode* [teks]
╠⊱ *${prefix}bpink* [teks]
╚⊱ *${prefix}party* [teks]

*Fun*
╔⊱ *${prefix}gtts* [cc] [teks]
╠⊱ *${prefix}hilih* [teks]
╠⊱ *${prefix}namajepang* [nama]
╠⊱ *${prefix}meme*
╚⊱ *${prefix}memeindo*

*Grup*
╔⊱ *${prefix}add*
╠⊱ *${prefix}kick*
╠⊱ *${prefix}bc*
╠⊱ *${prefix}cn*
╠⊱ *${prefix}promote* [@tag]
╠⊱ *${prefix}demote* [@tag]
╠⊱ *${prefix}opengc*
╠⊱ *${prefix}closegc*
╠⊱ *${prefix}linkgc*
╠⊱ *${prefix}tagall*
╠⊱ *${prefix}clearall*
╠⊱ *${prefix}listadmins*
╠⊱ *${prefix}clone*
╠⊱ *${prefix}setprefix* [text]
╠⊱ *${prefix}simih* [0/1]
╚⊱ *${prefix}welcome* [0/1]

*Others*
╔⊱ *${prefix}ytsearch* [teks]
╠⊱ *${prefix}chord* [judul]
╠⊱ *${prefix}lirik* [judul]
╠⊱ *${prefix}tiktok* [link]
╠⊱ *${prefix}tiktokstalk* [username]
╠⊱ *${prefix}url2img* [tipe] [link]
╠⊱ *${prefix}blocklist*
╠⊱ *${prefix}cat*
╠⊱ *${prefix}viewedfilm*
╠⊱ *${prefix}ocr* (reply with image)
╠⊱ *${prefix}wait* (what is anime)
║
╠⊱ *${prefix}info* Untuk melihat Informasi Bot.
╚═⊱ *Donasi?* *087898728747*

*Powered By Optimus J2 Prime*
Terima Kasih Untuk *MhankBarBar*`
}

exports.help = help
